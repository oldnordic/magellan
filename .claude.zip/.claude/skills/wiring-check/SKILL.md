---
name: wiring-check
description: Verify that all code changes are properly wired into the project. Checks for dead modules, unconnected optimizations, stale column names, and missing integrations.
---

# wiring-check

Run a comprehensive wiring verification across the magellan project and its downstream tools (mirage, llmgrep).

## Usage

```
/wiring-check
```

## Checks Performed

### 1. Dead Module Detection
- Scans `src/graph/mod.rs` for `pub mod` declarations
- Verifies each module is imported or used somewhere in `src/`
- Reports any module that is only used in its own tests

### 2. Indexing Pipeline Consistency
- Verifies `index_file()` and `index_file_incremental()` both use `parsed_tree`
- Checks that symbol extraction, AST extraction, import extraction, and CFG extraction reuse the pre-parsed tree
- Reports any extractor that calls `pool::with_parser(..., |p| p.parse(...))` after `parsed_tree` is available

### 3. Debug Message Cleanup
- Ensures no `debug_print!` macros exist in `src/`
- Ensures no `debug-prints` feature references remain in `#[cfg(...)]` attributes
- Ensures no `eprintln!("[DEBUG")` or `println!("[DEBUG")` patterns exist

### 4. Downstream Tool Compatibility
- **mirage**: Checks `cfg_hash` column is used (not `function_hash`)
- **mirage**: Verifies `.magellan/magellan.db` is in auto-discovery
- **llmgrep**: Verifies `schema_check.rs` exists and is wired into backends

### 5. Schema Drift Detection
- Checks `cfg_blocks` column references match current schema
- Checks `cfg_edges` table is created with the correct schema

## Commands Used

```bash
# Dead modules
grep -n "pub mod" src/graph/mod.rs | while read line; do mod=$(echo $line | sed 's/.*pub mod \([^;]*\);.*/\1/'); grep -rn "${mod}::" src/ --include="*.rs" | grep -v "${mod}.rs:" | head -1 || echo "DEAD: $mod"; done

# Indexing pipeline parse-once
grep -n "pool::with_parser.*parse" src/graph/ops.rs

# Debug messages
grep -rn "debug_print!" src/
grep -rn "cfg(feature = \"debug-prints\")" src/

# Mirage compatibility
grep -rn "function_hash" /home/feanor/Projects/mirage/src/ --include="*.rs" | grep -v "// .*function_hash"

# llmgrep compatibility
ls /home/feanor/Projects/llmgrep/src/backend/schema_check.rs
```

## Exit Codes
- `0` — All wiring checks passed
- `1` — One or more wiring issues found (see report)
