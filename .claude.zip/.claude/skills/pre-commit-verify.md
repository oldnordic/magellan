# Magellan Pre-Commit Verification

Run this skill before committing any changes to the Magellan codebase.

## Purpose

Ensure all critical tests pass and CLI commands work before allowing a commit. This prevents broken code from entering the repository.

## Verification Steps

Execute the following checks in order. STOP and report failures immediately.

### 1. Compilation Check

Verify both default and geometric backend builds compile:

```bash
cargo build --jobs 1
cargo build --jobs 1 --features geometric-backend
```

### 2. Critical Unit Tests

Run tests sequentially (limit 1 job to avoid RAM exhaustion):

```bash
# Default backend tests
cargo test --jobs 1 --test cfg_mir_parity_tdd
cargo test --jobs 1 --test backend_migration_tests
cargo test --jobs 1 --test fqn_integration_tests
cargo test --jobs 1 --test churn_harness_test

# Geometric backend tests (requires ../geographdb-core)
cargo test --jobs 1 --features geometric-backend --test geometric_mir_parity_tdd
cargo test --jobs 1 --features geometric-backend --test geometric_cfg_tests
cargo test --jobs 1 --features geometric-backend --test geometric_ast_chunk_tests
cargo test --jobs 1 --features geometric-backend --test churn_harness_test
```

### 3. Lib Tests

```bash
cargo test --jobs 1 --lib
cargo test --jobs 1 --features geometric-backend --lib
```

### 4. CLI Smoke Tests

Build release binary and verify core commands:

```bash
cargo build --release --jobs 1

# Create temp DB and index a file
DB=$(mktemp)
TMPDIR=$(mktemp -d)
echo 'fn main() { println!("hello"); }' > "$TMPDIR/test.rs"
./target/release/magellan status --db "$DB"
# Run watch in background to scan, then kill it (watch persists otherwise)
./target/release/magellan watch --root "$TMPDIR" --db "$DB" --scan-initial &
WATCH_PID=$!
sleep 2
kill $WATCH_PID 2>/dev/null
wait $WATCH_PID 2>/dev/null
./target/release/magellan find --db "$DB" --name "main"
./target/release/magellan query --db "$DB" --file "$TMPDIR/test.rs"
./target/release/magellan refs --db "$DB" --name "main" --path "$TMPDIR/test.rs"
./target/release/magellan doctor --db "$DB"
rm -f "$DB" && rm -rf "$TMPDIR"
```

### 5. Optional: Run Verification Script

If `scripts/verify-pre-commit.sh` exists, run it:

```bash
./scripts/verify-pre-commit.sh
```

## Rules

- **Use `--jobs 1`** for all cargo commands to prevent RAM exhaustion
- **Report each result** as PASS or FAIL with evidence
- **Do NOT claim success** without running the actual commands
- **If any check fails**, stop and report the failure before proceeding
- Known pre-existing failures (unrelated to current changes):
  - `phase1_persistence_compatibility` tests (error message format mismatch)

## What to Do If Tests Fail

1. Identify which test failed and read the error message
2. Determine if the failure is related to your changes
3. If related: fix the issue and re-run verification
4. If unrelated pre-existing: note it but do not block commit on it
