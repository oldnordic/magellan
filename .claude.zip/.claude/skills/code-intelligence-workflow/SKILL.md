---
name: code-intelligence-workflow
description: Grounded coding workflow using magellan, llmgrep, mirage, splice. Enforce query-before-code, verify-after, zero guessing.
---

# Code Intelligence Workflow

**Philosophy:** ZERO GUESSING. Query ground truth before coding. Verify after. Never assume.

**Core Principle:** Query the code graph database BEFORE writing any code. The database is truth. Memory is unreliable.

---

## What Does Not Work (Proven Failure Modes)

**Why LLMs Fail at Coding (Not Capability, Incentives):**

```
LLM Training Objective (RLHF):
─────────────────────────────────────────────────────
✓ Be helpful (give answers, not questions)
✓ Be confident (uncertainty = failure signal)
✓ Be fast (verification = latency = bad)
✓ Be positive (bad news = user dissatisfaction)

Coding Reality:
─────────────────────────────────────────────────────
✗ Files don't exist until verified
✗ Signatures must match EXACTLY
✗ Code must compile (no stubs allowed)
✗ "I don't know" is the HONEST answer
✗ Verification takes TIME
```

**Result:** LLMs hallucinate file paths, invent function signatures, create stub code, say "done" when not verified.

**Proven failures:**
- 1M context windows — Context gets forgotten, compacted, lost
- Better training data — Training fights against RLHF helpfulness bias
- Prompt engineering — Prompts don't override "be helpful/fast/confident" incentives
- Optional tools — LLMs skip them to deliver faster
- Session transcripts as memory — Too large, compacted, lost between sessions

---

## What Actually Works

**User built these tools alone, 5pm-midnight, 10 months:**
- magellan (symbol graph)
- llmgrep (semantic search)
- mirage (CFG analysis)
- splice (span-safe editing)
- sqlitegraph (35 graph algorithms)

**The Discipline (What Must Be Enforced):**

```
BEFORE ANY CODE CHANGE:
─────────────────────────────────────────────────────
1. QUERY: What symbols exist? (magellan find)
2. QUERY: What calls this? (magellan refs)
3. QUERY: What's the CFG? (mirage cfg)
4. QUERY: What's the schema? (sqlitegraph query)

AFTER ANY CODE CHANGE:
─────────────────────────────────────────────────────
1. VERIFY: Does symbol exist? (magellan verify)
2. VERIFY: Does it compile? (cargo check)
3. VERIFY: Tests pass? (cargo test)
4. UPDATE: Graph database (magellan watch)
```

**This is not optional. This is ENFORCEMENT.**

---

## Database Locations

Each project has its own isolated database:

```
/home/feanor/Projects/magellan/.magellan/magellan.db
/home/feanor/Projects/llmgrep/.magellan/llmgrep.db
/home/feanor/Projects/mirage/.magellan/mirage.db
/home/feanor/Projects/splice/.magellan/splice.db
```

**CRITICAL WORKFLOW RULE:** When working on magellan/llmgrep/mirage/splice codebases, use magellan/llmgrep/mirage to query that same codebase.

**Example:** To modify magellan's `src/migrate_cmd.rs`:
```bash
# WRONG: Using grep, rg, or assuming file structure
# RIGHT: Using magellan to query magellan's own database
magellan find --db /home/feanor/Projects/magellan/.magellan/magellan.db --name "migrate_from_version"
llmgrep search --db /home/feanor/Projects/magellan/.magellan/magellan.db --query "schema_version" --mode symbols
```

**Why:** The code intelligence tools ARE the ground truth for their own codebases. Using external tools (grep, rg) bypasses the indexed knowledge and risks working with outdated assumptions.

**NEVER assume schema. ALWAYS query first.**

---

## Pre-Code Queries (Mandatory)

Before writing ANY code, run these queries:

### 1. Check Database Health

```bash
magellan status --db <path/to/db>
magellan doctor --db <path/to/db>
mirage status --db <path/to/db>
splice status --db <path/to/db>
```

**What to verify:**
- Schema version matches (v12 for magellan/llmgrep/splice)
- No corruption errors
- Symbol count > 0

### 2. Find Existing Symbols

```bash
# Find symbol by name
magellan find --db <db> --name "function_name"

# Find all symbols in file
magellan query --db <db> --file "src/path/to/file.rs"

# List all indexed files
magellan files --db <db>
splice files --db <db>
```

**DO NOT invent function names. Query first.**

### 3. Check References/Callers

```bash
# See what calls this symbol
magellan refs --db <db> --name "function_name"

# Semantic search for pattern
llmgrep search --db <db> --query "pattern" --mode symbols
llmgrep search --db <db> --query "pattern" --mode references
```

**DO NOT assume usage patterns. Query first.**

### 4. Analyze Control Flow

```bash
# Get CFG for function
mirage cfg --db <db> --function "function_name"

# Find execution paths
mirage paths --db <db> --function "function_name"

# Find hotspots (MUST use --inter-procedural)
mirage hotspots --db <db> --inter-procedural

# Detect cycles
mirage cycles --db <db>
splice cycles --db <db>
```

**DO NOT assume control flow. Query first.**

---

## Code Changes (Verified)

### 1. Safe Editing with Splice

```bash
# Plan a rename
splice plan --db <db> rename --name "old" --new-name "new"

# Execute rename
splice rename --db <db> --name "old" --new-name "new"

# Patch with span safety
splice patch --db <db> --file "src/file.rs" --old "code" --new "code"
```

### 2. Create New Files

```bash
splice create --db <db> --file "src/new.rs" --content "..."
```

### 3. Batch Operations

```bash
splice batch --db <db> operations.yaml
```

---

## Post-Code Verification (Mandatory)

After ANY code change, verify:

### 1. Compile Check

```bash
cargo check
cargo test
```

**DO NOT say "done" without compilation.**

### 2. Update Code Graph

```bash
# Re-index after changes
magellan watch --db <db> --root /path/to/project

# Or full re-index
magellan index --db <db> /path/to/project
```

### 3. Verify Graph Integrity

```bash
splice cycles --db <db>
magellan doctor --db <db>
mirage status --db <db>
```

### 4. Test Queries Still Work

```bash
# Query the symbol you just created/modified
magellan find --db <db> --name "your_new_function"

# Verify refs work
magellan refs --db <db> --name "your_new_function"
```

---

## Enforcement Hooks

**Location:** `/home/feanor/Projects/magellan/.claude/hooks/`

These hooks ENFORCE the workflow. They are not optional. They BLOCK subagents that violate the discipline.

### Hook 1: `query-schema-check.fish` (SubagentStart)

**Purpose:** Block subagent from starting if database is unhealthy.

**Checks:**
1. Database exists (`.magellan/magellan.db`)
2. Database healthy (`magellan status`)
3. No schema drift (`magellan doctor`)
4. No concurrent access (WAL lock detection)

**Exit Codes:**
- `0` = All checks passed, subagent can start
- `2` = Database unhealthy, BLOCK subagent

---

### Hook 2: `query-symbol-check.fish` (SubagentStop)

**Purpose:** Block subagent from completing if no ground truth queries were run before coding.

**Checks:**
1. Rust files modified?
2. Terminal history contains magellan/llmgrep queries?
3. Queries reference modified files?

**Exit Codes:**
- `0` = Queries verified, subagent can complete
- `2` = No queries found, BLOCK completion

---

### Hook 3: `verify-rust.fish` (SubagentStop)

**Purpose:** Verify code compiles AND graph is updated.

**Checks:**
- `cargo fmt --check`
- `cargo check`
- `magellan watch` (update code graph)
- Graph update verification (symbol count)

**Exit Codes:**
- `0` = Code compiles, graph updated
- `2` = Compilation failed, BLOCK completion

---

### Hook 4: `splice-cycles-check.fish` (SubagentStop)

**Purpose:** Detect call graph cycles after refactoring.

**Checks:**
1. Significant code changes (>20 lines)?
2. `splice cycles` command
3. Cycle detection analysis

**Exit Codes:**
- `0` = No cycles detected
- `2` = Cycles found, BLOCK completion (requires review)

---

### Hook 5: `stub-check.fish` (SubagentStop)

**Purpose:** Detect stub code (`panic!` in non-test files).

**Exit Codes:**
- `0` = No stubs found
- `2` = Stubs found, BLOCK completion

---

### Hook 6: `wiring-check.fish` (SubagentStop)

**Purpose:** Verify wiring (dead modules, parse-once consistency, debug cleanup).

**Exit Codes:**
- `0` = Wiring clean
- `2` = Wiring issues found, BLOCK completion

---

### Settings Integration

**File:** `/home/feanor/Projects/magellan/.claude/settings.json`

```json
{
  "hooks": {
    "SubagentStart": ["query-schema-check.fish"],
    "SubagentStop": [
      "query-symbol-check.fish",
      "verify-rust.fish",
      "splice-cycles-check.fish",
      "stub-check.fish",
      "wiring-check.fish"
    ]
  }
}
```

---

## Known Bugs & Workarounds

### Bug 1: Path normalization in CodeGraph API (FIXED 2026-05-03)

**Symptom:**
```rust
// Test fails: symbols_in_file() returns 0 after index_file()
graph.index_file("test.rs", source)?;
let symbols = graph.symbols_in_file("test.rs")?;
assert_eq!(symbols.len(), 2); // FAILED: got 0
```

**Root Cause:** `index_file()` stores normalized absolute paths in `file_index`, but query/delete functions used raw relative paths for `file_index` lookups. Stale entries after delete caused "entity not found" panics.

**Fixes Applied:**
- `find_file_node()` normalizes before lookup
- `find_or_create_file_node()` normalizes before storage
- ALL `file_index.get()` and `file_index.remove()` calls in `ops.rs` now normalize
- `get_ast_nodes_by_file()`, `resolve_query_path()`, `symbol_id_by_name()` normalized

**Status:** FULLY FIXED. All lib tests (574), delete_transaction_tests (12), delete_orphan_tests (12) pass.

---

### Bug 2: `magellan find --list-glob "*"` returns empty — FIXED IN 3.1.9

**Previous Status:** Returned "No symbols matched glob '*'"
**Current Status:** WORKS. Returns all matching symbols.

**Verified:**
```bash
$ magellan find --db .magellan/magellan.db --list-glob "*"
Matched 3144 symbols for glob '*':
```

---

### Bug 3: `mirage hotspots` (without --inter-procedural) shows 0 — FIXED IN 1.2.5

**Previous Status:** Returned "Found 0 hotspots out of 0 functions"
**Current Status:** WORKS. Returns hotspots without flag.

**Verified:**
```bash
$ mirage hotspots --db .magellan/magellan.db
===> Hotspots Analysis (entry: main)
[INFO] Found 3 hotspots out of 3 functions
```

---

### Bug 4: `splice query --file` semantics differ from magellan

**Symptom:**
```bash
splice query --db <db> --file "src/main.rs"
# Returns: "No labels specified. Use --label <LABEL> or --list"
```

**Workaround:**
```bash
# Use magellan query instead
magellan query --db <db> --file "src/main.rs"
```

**Root Cause:** splice query uses `--label` filtering, not `--file`. The `--file` flag exists but the command semantics differ.

---

### Bug 5: `magellan query` requires --file flag

**Symptom:**
```bash
magellan query --db <db>
# Returns: "Error: --file is required unless --explain is used"
```

**Workaround:**
```bash
# List files first, then query each
magellan files --db <db> | xargs -I {} magellan query --db <db> --file {}
```

**Root Cause:** magellan query designed for file-level queries only.
**Fix Location:** `magellan/src/query_cmd.rs` — make --file optional, allow global queries.

---

### Bug 6: `magellan dead-code --entry` takes name not ID, no --path

**Symptom:**
```bash
# Documentation claimed --entry <SYMBOL_ID> --path <file>
# Actual CLI rejects --path:
magellan dead-code --db <db> --entry "main" --path src/main.rs
# Error: Unknown argument: --path
```

**Workaround:**
```bash
# Use symbol name only
magellan dead-code --db <db> --entry "main"
```

---

### Bug 7: `splice refs` requires --path flag

**Symptom:**
```bash
splice refs --db <db> --name "main"
# Returns: "error: the following required arguments were not provided: --path <PATH>"
```

**Workaround:**
```bash
# Always specify file path
splice refs --db <db> --name "main" --path "src/bin/detect_debug.rs"
```

**Root Cause:** splice refs designed to require explicit file path (safer, but more verbose).
**Design Decision:** Intentional — avoids ambiguity when symbol exists in multiple files.

---

### Bug 8: Tool visibility gap — FALSE ALARM (transient database state)

**Status:** NOT A BUG — caused by transient database state during re-indexing.

**Original Symptom:**
```bash
$ splice find --db <db> --name "normalize_path_for_index"
# Error: Symbol 'normalize_path_for_index' not found
```

**Investigation Results:**
- **No visibility filtering exists** in splice or mirage source code
- The database schema has **no `visibility` field** — visibility info is never stored
- Both tools use the same `CodeGraph::symbol_extents()` path lookup as magellan
- `splice find` uses exact name matching (`==`), magellan uses substring (`contains()`) — this is intentional design, not a bug

**Root Cause:** Transient database inconsistency during concurrent re-indexing. When the watcher re-indexes a file, it temporarily deletes and recreates file nodes + DEFINES edges. Queries issued during this window may see incomplete state.

**Verification:**
```bash
$ splice find --db <db> --name "normalize_path_for_index"
# Found: 1 symbol(s): fn :: normalize_path_for_index at src/graph/files.rs:56

$ mirage cfg --db <db> --function "normalize_path_for_index"
# Returns valid CFG graph
```

**Lesson:** If a tool "misses" a symbol that magellan finds, check database health first (`magellan doctor`) before assuming a visibility bug.

---

### Bug 9: `splice` tree-sitter validation gate was BROKEN (FIXED 2026-05-02)

**Symptom (BEFORE FIX):**
```rust
// In splice/src/verify.rs:
result.syntax_ok = true;  // ← ALWAYS PASSED, NEVER CHECKED
```

**Fix Applied:**
1. Created `splice/src/syntax_validator.rs` — tree-sitter parsing for 8 languages
2. Integrated into `splice/src/verify.rs`
3. Tests added for valid/invalid syntax and unknown language

**Status:** FIXED (2026-05-02)

---

### Bug 10: Splice required absolute paths — FIXED 2026-05-03

**Symptom:**
```bash
$ splice dead-code --db <db> --entry "main" --path src/main.rs
# Error: Entry point 'main' not found in 'src/main.rs'

$ splice reachable --db <db> --symbol "foo" --path src/lib.rs
# Error: Symbol 'foo' not found in 'src/lib.rs'
```

**Root Cause:** Splice passed raw CLI paths directly to database lookups, but Magellan stores canonical absolute paths. Relative paths like `src/main.rs` never matched `/home/user/project/src/main.rs`.

**Fixes Applied (splice 2.6.3):**
- Added `normalize_lookup_path()` helper in `resolve/mod.rs` and `graph/magellan_integration.rs`
- Tries `std::fs::canonicalize` for existing files, falls back to `current_dir().join()`
- Applied to: `resolve_symbol`, `find_symbol_or_suggest`, `find_symbol_by_path_and_name`, `get_call_relationships`, `reachable_symbols`, `reverse_reachable_symbols`, `dead_symbols`

**Status:** FIXED. All splice graph commands now accept relative paths.

---

### Bug 11: Splice semantic/LSP validation gate STILL BROKEN

**Symptom:**
```rust
// In splice/src/verify.rs:
result.semantic_ok = true;  // ← STILL ALWAYS PASSES
```

**Impact:** Type errors, unresolved imports, and semantic issues pass validation.

**Current Workaround:**
```bash
# Use rustc --emit=metadata (what splice currently does)
# This catches type errors but NOT full LSP diagnostics
```

**To Fix Properly:**
1. Replace `rustc --emit=metadata` with actual rust-analyzer LSP integration
2. Use LSP `textDocument/diagnostics` or `rust-analyzer` CLI
3. Parse LSP diagnostics, not rustc output

**Status:** NOT YET FIXED — requires rust-analyzer LSP integration

---

## Test Report Reference

Full CLI test report with 54 commands tested:

**Location:** `/home/feanor/Downloads/TOOLCHAIN-TEST-REPORT-2026-05-01.md`

**Summary (as of 2026-05-01):**
- PASS: 48 commands
- PARTIAL: 3 commands (workarounds available)
- FAIL: 3 commands

**Updates since report:**
- `magellan find --list-glob "*"` — FIXED in 3.1.9
- `mirage hotspots` (without --inter-procedural) — FIXED in 1.2.5
- `delete_file_facts` path normalization — FIXED in commits b40f885, 350d85c, + 8 file_index fixes

**Test Database:** `/home/feanor/Projects/llmgrep/.magellan/llmgrep.db` (Healthy, Schema v12)

---

## Debugging Workflow

When something breaks:

### 1. Check Database Health

```bash
magellan doctor --db <db>
```

### 2. Look for Schema Drift

```bash
# Check schema versions
magellan status --db <db>
mirage status --db <db>

# If mismatch, re-index
rm <db>
magellan index --db <db> /path/to/project
```

### 3. Check for Corruption

```bash
# Look for backup/corrupt files
ls -la /path/to/project/.magellan/bad-db/

# If corruption, restore from backup
cp /path/to/project/.magellan/bad-db/*.db.* /path/to/project/.magellan/db.db
```

### 4. Verify Tool Versions

```bash
magellan --version
llmgrep --version
mirage --version
splice --version

# All should be compatible (schema v12)
```

---

## Session Checklist

**Before starting work:**

- [ ] Identify project database path
- [ ] Run `magellan status --db <db>` (verify healthy)
- [ ] Run `magellan doctor --db <db>` (check for issues)

**Before writing code:**

- [ ] Query existing symbols: `magellan find --db <db> --name "..."`
- [ ] Check references: `magellan refs --db <db> --name "..."`
- [ ] Search patterns: `llmgrep search --db <db> --query "..."`
- [ ] Analyze CFG: `mirage cfg --db <db> --function "..."`

**After writing code:**

- [ ] Run `cargo check` (must compile)
- [ ] Run `cargo test` (tests must pass)
- [ ] Re-index: `magellan watch --db <db>`
- [ ] Verify graph: `splice cycles --db <db>`

**Before ending session:**

- [ ] Note any schema changes for future sessions

---

## Anti-Patterns (Never Do These)

**Never assume a function exists without querying:**
```bash
# WRONG: Writing code that calls non-existent function
# RIGHT: magellan find --db <db> --name "function"
```

**Never invent schema/column names:**
```bash
# WRONG: "I'll add a 'created_at' column"
# RIGHT: sqlite3 <db> ".schema"  # See actual schema
```

**Never skip verification:**
```bash
# WRONG: "Code looks good, done!"
# RIGHT: cargo check && cargo test && magellan status --db <db>
```

**Never work without database:**
```bash
# WRONG: Coding blind
# RIGHT: Always have --db flag ready
```

**Never ignore doctor warnings:**
```bash
# WRONG: "magellan doctor shows issues, but I'll continue"
# RIGHT: Fix schema issues FIRST, then code
```

---

## Example Sessions

### Example 1: Add New Function

```bash
# 1. Check existing functions
magellan find --db <db> --name "similar_function"

# 2. See how similar functions are structured
magellan query --db <db> --file "src/lib.rs"

# 3. Write code (after understanding patterns)

# 4. Verify
cargo check
magellan watch --db <db>
magellan find --db <db> --name "your_new_function"
```

### Example 2: Refactor/Rename

```bash
# 1. Find what needs renaming
magellan find --db <db> --name "old_name"

# 2. Check references
magellan refs --db <db> --name "old_name"

# 3. Plan rename
splice plan --db <db> rename --name "old_name" --new-name "new_name"

# 4. Execute
splice rename --db <db> --name "old_name" --new-name "new_name"

# 5. Verify
splice cycles --db <db>
cargo test
```

### Example 3: Debug Dead Code

```bash
# 1. Find dead code from entry point
magellan dead-code --db <db> --entry "main"

# 2. Review list

# 3. Delete if confirmed dead
splice delete --db <db> --name "dead_function"

# 4. Verify
magellan dead-code --db <db> --entry "main"
cargo test
```

---

## Success Criteria

A session is successful when:

- All code compiles (`cargo check`)
- All tests pass (`cargo test`)
- Code graph is updated (`magellan status` shows new symbols)
- No cycles introduced (`splice cycles` clean)
- Schema is healthy (`magellan doctor` passes)

---

## When Stuck

1. **Query the database** — What actually exists?
2. **Check the report** — `/home/feanor/Downloads/TOOLCHAIN-TEST-REPORT-2026-05-01.md`
3. **Run doctor** — `magellan doctor --db <db>`
4. **Ask for help** — "What queries should I run before this change?"

---

## Related Skills

- `code-intelligence-ecosystem` — Overview of all code intelligence tools
- `graph-query` — Quick queries without typing --db every time
- `wiring-check` — Verify code changes are properly wired
- `systematic-debugging` — 4-phase root cause debugging
- `test-driven-development` — RED-GREEN-REFACTOR discipline

---

**Remember:** The database is truth. Your memory is not. Query first. Verify after. Zero guessing.
