---
name: code-intelligence-ecosystem
description: Code intelligence tool stack including magellan, llmgrep, mirage, splice, sqlitegraph, odincode, and geometric_db. Grounded truth, zero guessing, verifiable operations.
---

# Code Intelligence Ecosystem

User has built a coherent stack of code intelligence tools with shared philosophy: **grounded truth, zero guessing, verifiable operations**.

## Living Projects

| Project | Version | Purpose | Location |
|---------|---------|---------|----------|
| **GeoMetriDB** (geometric_db_concept) | Research prototype | **PRIMARY graph DB** — 3D octree + G3-A* pathfinding + MVCC temporal queries. 110 storage tests + 18 integration tests passing. Urban drone nav (Phase 2), swarm coordination (Phase 2), flight software (Phase 1). | `/home/feanor/Projects/geometric_db_concept/` |
| **sqlitegraph** | v2.1.3 | Published crates.io package — dual backend (SQLite + native V3), 35+ graph algorithms, HNSW vector search. Use for external distribution, NOT for internal brainstorming/knowledge graphs. | `/home/feanor/Projects/sqlitegraph/` |
| **magellan** | v3.1.9 | Deterministic codebase indexer (AST, symbols, CFG, calls). **FTS5 full-text search** (schema v12, 2.5× faster prefix queries). | `/home/feanor/Projects/magellan/` |
| **llmgrep** | v3.1.7 | Semantic code search on magellan databases. Supports schema v12 (FTS5 index). | `/home/feanor/Projects/llmgrep/` |
| **mirage** | v1.2.5 | Control-flow analysis (paths, dominance, loops, dead code). | `/home/feanor/Projects/mirage/` |
| **splice** | v2.6.2 | Span-safe refactoring (byte-accurate edits, cross-file rename) | `/home/feanor/Projects/splice/` |
| **odincode** | v0.0.1 | Deterministic tool substrate for LLM refactoring (1,037 tests) | `/home/feanor/Projects/odincode/` |

**Critical Distinction:** GeoMetriDB is the flagship graph database (10 months engineering). sqlitegraph is a published crate for external use. **Dogfood GeoMetriDB for internal work** — brainstorming graphs, knowledge maps, idea traversal.

## Dead Projects (Do Not Pursue)

- **SynCore** — GPU inference pipeline, Candle GGUF, MCP server (abandoned)
- **LTMS** — Revolutionary transformation, centralized DB refactoring (abandoned)
- **LTMC** — Long-Term Memory Consolidation, Python MCP server (abandoned — MCP proved to be dead end)
- **CodeGraph** — Earlier graph iteration before sqlitegraph (abandoned)

Pattern: Ideas evolved into simpler, more focused tools. Don't revive dead projects; build on living ones.

## Critical Lesson: Why Optional Tools Fail

**MCP (Model Context Protocol) and similar optional tool systems are dead ends for grounded coding.** User proved this through LTMC experience.

**The Problem:**
- Optional tools are OPTIONAL — model must choose to call them (can ignore and hallucinate anyway)
- One-way flow — query → answer (no enforcement, no gates)
- No hooks — cannot BLOCK unverified code changes
- Model incentives fight truth — "be helpful/fast/confident" overrides "query first"

**What Actually Works:**
- **SKILLS (not tools)** — workflow encoded in context, loaded automatically every session
- **ENFORCEMENT LAYER** — hooks that FORCE query before any code write
- **PRE-CODE GATES** — cannot write file without magellan/llmgrep query
- **POST-CODE VERIFICATION** — code must compile, symbols must exist, tests must pass
- **HONESTY PROTOCOL** — "I don't know" = ACCEPTABLE, "let me query" = EXPECTED, "I'll guess" = REJECTED

**Key Insight:** The problem isn't tools — it's INCENTIVES. LLMs are trained to be helpful, confident, and fast. This fights against verification, uncertainty, and query-first workflows. You must ENFORCE truth, not suggest it.

## Release Discipline — GitHub First, Then crates.io

**CRITICAL: Never publish to crates.io without pushing to GitHub first.** crates.io links to repository README and license. If those are wrong on GitHub, crates.io shows wrong info permanently for that version.

### Pre-Release Checklist

**1. Documentation Audit (ALL projects):**
```bash
# Check public docs only (README.md, MANUAL.md, CHANGELOG.md, Cargo.toml)
grep -ri "LLM\|AI assistant\|production-ready" README.md MANUAL.md CHANGELOG.md Cargo.toml
grep "GPL-3.0-or-later" Cargo.toml  # Must be GPL-3.0 ONLY
```

**2. Enforcement Hooks (Local + GitHub):**
- `.git/hooks/pre-commit` — blocks commits before they leave your machine
- `.github/workflows/validate.yml` — blocks pushes on GitHub Actions

Both check:
- AI/LLM terminology in public docs
- `GPL-3.0-or-later` license (must be `GPL-3.0`)
- "production-ready" claims (use "stable")
- `cargo check --all-targets`
- `cargo test --all-targets`

**3. Push Order:**
```bash
# 1. Commit changes (local hook validates)
git add .
git commit -m "docs: remove AI/LLM terminology, fix license to GPL-3.0 only"

# 2. Push to GitHub FIRST (CI validates on server)
git push origin main

# 3. WAIT for GitHub Actions to pass
# https://github.com/oldnordic/<project>/actions

# 4. THEN publish to crates.io
cargo publish
```

### Documentation Standards

**Public docs (README.md, MANUAL.md, CHANGELOG.md, Cargo.toml):**
- NO AI/LLM terminology — this is a code intelligence toolchain, not an AI product
- NO "production-ready" claims — nothing is production-ready, only "stable"
- NO GPL-3.0-or-later — license is GPL-3.0 ONLY

**Internal docs (.planning/, .internal/, .magellan/, BUILD_*.md, TEST-*.md, etc.):**
- Can contain any terminology useful for development
- "LLM testing", "AI/ML research", "production-ready" as internal goals are fine
- These files are excluded from crates.io packages

### User's crates.io Profile

**Profile:** https://crates.io/users/oldnordic

**Published crates (14 total):**
| Crate | Downloads | Version (crates.io) | Version (local) |
|-------|-----------|---------------------|-----------------|
| magellan | 865 | v3.1.7 | v3.1.9 |
| llmgrep | 327 | v3.1.6 | v3.1.7 |
| mirage | - | v1.2.4 | v1.2.5 |
| splice | - | v2.6.1 | v2.6.2 |
| sqlitegraph | - | v2.1.3 | v2.1.3 |
| forgekit-* | - | various | various |
| aethermap-* | - | various | various |
| geographdb-core | - | v0.1.0 | v0.1.0 |

**All crates use GPL-3.0 license ONLY.**

### Pitfalls

- **Don't assume GitHub state** — Always check actual repositories before claiming what's published
- **Don't repeat pasted text as truth** — Verify download counts, versions, and claims with actual tools
- **Don't rush release** — "STOP trying to be fast, and be correct" — verification before publication
- **Don't skip enforcement** — Hooks protect against future mistakes; they're not optional
- **Per-project databases** — Each project has its own `.magellan/` folder. Databases are NOT shared across projects.

## Core Philosophy

From odincode's README:

> "LLMs are capable enough to write code. What they lack is truth: what exists, what changed, what failed, and what still needs doing. When those facts are stored and queryable, context compaction stops being a risk because the model can always re-ground itself on evidence instead of guessing."

**Epistemic Discipline Rules** (from odincode/AGENTS.md):

1. **NEVER GUESS - ALWAYS VERIFY** — Read source, check schema, run tests before any change
2. **TDD - PROVE IT FIRST** — Write failing test, show output, fix, show pass
3. **USE PROPER TOOLS** — magellan for symbols, splice for edits, compiler for validation
4. **CITE YOUR SOURCES** — Reference exact files and lines before changes
5. **NO DIRTY FIXES** — No `unwrap()` in prod, no TODOs, no `#[allow(dead_code)]`

## Tool Relationships

```
sqlitegraph (foundation: graph storage)
    ↓
magellan (indexer: AST → sqlitegraph)
    ↓
llmgrep (search: query magellan DB)
mirage (analysis: CFG from magellan)
splice (editing: span-safe ops on magellan graph)
    ↓
odincode (meta-layer: tool substrate enforcing discipline)
```

## Working With This Ecosystem

### Before Any Code Work

1. **Find the project's magellan database** — Each project has its own isolated database:
   ```bash
   # Project-specific database (NOT shared across projects)
   /home/feanor/Projects/<project>/.magellan/magellan.db

   # Examples:
   /home/feanor/Projects/magellan/.magellan/magellan.db
   /home/feanor/Projects/mirage/.magellan/mirage.db
   /home/feanor/Projects/splice/.magellan/splice.db
   ```

2. **Check database exists and is healthy**
   ```bash
   magellan status --db .magellan/magellan.db --output pretty
   ```

3. **If missing, index the codebase**
   ```bash
   magellan watch --root . --db .magellan/magellan.db --scan-initial
   ```

4. **Query before editing**
   ```bash
   llmgrep --db .magellan/magellan.db search --query "<symbol>" --output json
   ```

5. **Use splice for edits, not manual text replacement**
   ```bash
   splice patch --file src/lib.rs --symbol MyFunc --kind function --with patch.diff
   ```

6. **Validate with compiler**
   ```bash
   cargo check
   cargo test
   ```

### Common Commands

**magellan:**
```bash
magellan find --db code.db --name main
magellan refs --db code.db --name main --direction out
magellan reachable --db code.db --symbol <SYMBOL_ID>
magellan dead-code --db code.db --entry <SYMBOL_NAME>
magellan cycles --db code.db
```

**llmgrep:**
```bash
llmgrep --db code.db search --query "parse" --mode symbols
llmgrep --db code.db search --query "MyType" --mode references
```

**mirage:**
```bash
mirage --db code.db paths --function "main"
mirage --db code.db cfg --function "process"
mirage --db code.db cycles
```

**splice:**
```bash
splice status --db .magellan/magellan.db
splice find --db .magellan/magellan.db --name <symbol>
splice refs --db .magellan/magellan.db --name <symbol> --path <full-absolute-path>
splice reachable --db .magellan/magellan.db --symbol <symbol> --path <full-absolute-path>
splice dead-code --db .magellan/magellan.db --entry <symbol> --path <full-absolute-path>
# NOTE: splice dead-code requires --path; magellan dead-code does NOT accept --path
splice cycles --db .magellan/magellan.db
splice condense --db .magellan/magellan.db
splice complete --file src/lib.rs --line 27 --column 8 --db .magellan/magellan.db
```

**CRITICAL:** Splice uses the magellan database directly — NOT a separate `splice.db`. Always use `--db .magellan/magellan.db`. The `--path` argument requires FULL absolute paths.

## Project-Specific Notes

### sqlitegraph
- Published on crates.io (v2.1.3)
- Dual backend: SQLite (`.db`) and Native V3 (`.graph`)
- 35+ graph algorithms, HNSW vector search
- Benchmarks: V3 114× faster point lookup with LRU cache

### magellan
- 7 languages: Rust, Python, C, C++, Java, JavaScript, TypeScript
- tree-sitter parsing, stable symbol IDs
- CFG extraction, coverage ingestion (LCOV)
- LSIF/SCIP export

### odincode
- 1,037 tests passing
- Known issues: 2 critical bugs, 10 high-severity, 10 files >600 LOC
- TUI mode with chat interface
- Tool output limits in config.toml

### geometric_db_concept
- Research prototype (not for production)
- Urban drone navigation, GPS-denied localization
- Swarm coordination (Phase 2 complete)
- ROCm GPU acceleration (optional)

## Pitfalls

- **Don't use grep/rg for symbol search** — Use magellan/llmgrep for structured results
- **Don't edit files manually** — Use splice for span-safe operations
- **Don't assume database schema** — Check with `sqlite3 <db> ".schema"` or magellan doctor
- **Don't skip validation gates** — UTF-8 boundary check passes, compiler check passes, but tree-sitter parse and semantic validation are NOT fully implemented in Splice (always pass)
- **Don't revive dead projects** — SynCore, LTMS, CodeGraph are abandoned; build on living tools
- **Don't assume function names match implementation** — Splice's `run_rust_analyzer()` actually runs `rustc`, not rust-analyzer

## Debugging Methodology: Pipeline Tracing

**When numbers don't match (e.g., "8,338 embeddings → 1,949 loaded"):**

1. **Instrument each pipeline stage** — Count at entry, after each transform, at exit
2. **Python + Rust parity** — Replicate logic in both to isolate language-specific bugs
3. **Check ID matching** — Often the bug is mismatched snapshots (embeddings vs DB from different times)
4. **Verify assumptions** — "1,949 symbols" was outdated documentation, not a code bug
5. **Use example binaries** — `cargo run --example debug_foo` to test in isolation

**Pattern:** Most "bugs" are:
- Outdated documentation
- Snapshot mismatch (embeddings generated from old DB)
- Silent filtering (ID lookup fails, items dropped without error)

## Related Skills

- `code-intelligence-workflow` — Grounded coding workflow with enforcement patterns
- `graph-query` — Quick magellan/mirage queries without typing --db every time
- `wiring-check` — Verify code changes are properly wired into the project
- `systematic-debugging` — Apply 4-phase debugging when tools reveal issues
