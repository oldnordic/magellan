---
name: test-runner
description: Run relevant tests based on modified files using cargo test

Run the appropriate test suite based on which files were modified. Supports filtering by test name, running tests in parallel, and targeting specific feature flags.

**When to invoke this skill:**
- After modifying Rust source files
- Before committing changes
- When investigating test failures
- Validating changes across multiple feature flag combinations

**Examples:**
- "run all tests for the ops.rs file I just edited"
- "run cfg-related tests for the CFG changes I made"
- "run all tests with external-tools-cfg feature enabled"
