---
name: bench
description: Run benchmark suites with correct feature flags for magellan
---

# bench

Run Magellan benchmark suites with the correct feature flags.

## Usage

```
/bench [suite]
```

## Suites

| Suite | Command | Features |
|-------|---------|----------|
| `default` | `cargo bench` | none |
| `geometric` | `cargo bench --features geometric-backend,benchmarks` | geometric-backend |
| `cfg` | `cargo bench --bench cfg_bench` | none |
| `parsing` | `cargo bench --bench parsing_bottleneck` | none |
| `perf` | `cargo bench --bench perf_suite` | none |
| `context` | `cargo bench --bench context_bench` | none |
| `all` | Run all available benches | varies |

## Examples

```
/bench                    # Run default benchmarks
/bench geometric          # Run geometric backend benchmarks
/bench cfg                # Run CFG extraction benchmarks
/bench all                # Run all benchmark suites
```

## Notes

- Geometric benchmarks require `geographdb-core` at `../geographdb-core`
- Use `cargo build --features geometric-backend` before running geometric benches
