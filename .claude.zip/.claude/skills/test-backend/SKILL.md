---
name: test-backend
description: Run backend-specific test suites with correct feature flags for the magellan project. Supports sqlite (default), native-v3, and geometric backends.
---

# test-backend

Run tests for a specific backend or test category.

## Arguments

```
/test-backend <pattern> [backend]
```

| Argument | Description | Examples |
|----------|-------------|----------|
| `pattern` | Test file name prefix or specific test file | `geometric`, `cfg_mir_parity`, `v3_`, `migration` |
| `backend` | Optional backend feature to enable | `sqlite`, `native-v3`, `geometric` |

## Examples

```bash
# Run all geometric backend tests
/test-backend geometric geometric

# Run MIR parity tests (no backend feature needed)
/test-backend cfg_mir_parity

# Run native-v3 tests
/test-backend v3_ native-v3

# Run backend migration tests
/test-backend backend_migration

# Run a specific geometric test file
/test-backend geometric_cfg_tests geometric
```

## Rules

- If `backend` is `geometric`, always add `--features geometric-backend`
- If `backend` is `native-v3`, always add `--features native-v3`
- If `backend` is `sqlite` or omitted, run without extra features
- Use `--test <pattern>` when pattern matches a specific test file
- Use `--test <pattern>_tests` as fallback if exact match fails
