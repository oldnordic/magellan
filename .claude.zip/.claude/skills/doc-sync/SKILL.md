---
name: doc-sync
description: Synchronize all user-facing documentation with current codebase state (versions, dependencies, features, API changes). Checks CHANGELOG, README, MANUAL, ARCHITECTURE, and feature-specific docs for consistency.
disable-model-invocation: false
user-invocable: true
---

# Documentation Synchronization Skill

Ensures all user-facing documentation is consistent with the current codebase state.

## What This Skill Does

1. **Version Consistency Check**
   - Verifies version numbers match across: `Cargo.toml`, `CHANGELOG.md`, `README.md`, `MANUAL.md`
   - Checks dependency versions in docs match `Cargo.toml` and `Cargo.lock`
   - Validates schema version references

2. **Dependency Documentation Check**
   - Ensures all external dependencies are documented
   - Verifies version-specific pins are explained (e.g., sqlitegraph 2.0.7 pin)
   - Checks that feature flags are documented

3. **Changelog Completeness**
   - Verifies CHANGELOG.md has entries for all recent changes
   - Checks that unreleased section is properly categorized
   - Ensures dated releases have proper entries

4. **API Documentation Sync**
   - Checks that new public APIs are documented
   - Verifies deprecated APIs are marked in docs
   - Ensures breaking changes are noted

5. **Feature Documentation**
   - Validates that all feature flags have documentation
   - Checks experimental features are marked as such
   - Ensures platform-specific limitations are documented

## When to Use

Invoke this skill when:
- After releasing a new version
- After adding new dependencies or changing versions
- After implementing new features or APIs
- After deprecating functionality
- Before creating a release commit
- After fixing bugs that affected user-facing behavior

## Workflow

### Phase 1: Gather Current State

```bash
# Get current version from Cargo.toml
grep "^version = " Cargo.toml

# Get dependency versions
grep -A 50 "\[dependencies\]" Cargo.toml | grep -E "version =|path ="

# Check locked versions
grep -A 2 'name = "sqlitegraph"' Cargo.lock

# List all feature flags
grep "^features = " Cargo.toml -A 20
```

### Phase 2: Check Documentation Files

Verify these files exist and are up-to-date:

1. **CHANGELOG.md**
   - Has `[Unreleased]` section with recent changes
   - Has dated entries for all releases
   - Entries categorized: Added, Changed, Deprecated, Removed, Fixed, Security

2. **README.md**
   - Version matches `Cargo.toml`
   - Installation instructions work
   - Feature flags documented
   - Dependencies mentioned (if user-visible)

3. **MANUAL.md**
   - Dependency versions current (e.g., sqlitegraph version)
   - Commands match current CLI
   - Examples work with current version
   - Platform limitations noted

4. **ARCHITECTURE.md**
   - Component versions specified
   - Schema version matches code
   - Design decisions explained

5. **CLAUDE.md**
   - Development rules current
   - Build instructions work
   - Test coverage notes accurate

### Phase 3: Consistency Checks

Cross-reference these data points:

| Source | Must Match |
|--------|-----------|
| `Cargo.toml` version | `README.md`, `CHANGELOG.md` |
| `Cargo.toml` dependencies | `MANUAL.md`, `ARCHITECTURE.md` |
| `Cargo.lock` sqlitegraph version | Any sqlitegraph references in docs |
| Feature flags in `Cargo.toml` | Feature documentation |
| Public API in `src/lib.rs` | API documentation |
| Schema version in code | Architecture docs |

### Phase 4: Generate Report

Produce a report with:

```markdown
# Documentation Sync Report

## ✅ Consistent
- Version: 3.1.6 matches across Cargo.toml, README, CHANGELOG
- sqlitegraph: 2.0.7 pinned in Cargo.toml, explained in CHANGELOG

## ⚠️ Needs Update
- MANUAL.md line 1501: References sqlitegraph 1.3.0 (should be 2.0.7)
- ARCHITECTURE.md: Missing sqlitegraph version specification

## ❌ Missing
- No documentation for new `--enrich` flag in MANUAL.md
- CHANGELOG.md: Missing entry for cfg_blocks schema fix

## 🔍 Recommended Actions
1. Update MANUAL.md sqlitegraph version reference
2. Add CHANGELOG entry for migration fix
3. Document enrich command in MANUAL.md
```

## Quick Checks

Run these commands to verify consistency:

```bash
# Version consistency
grep -h "^version\|**Version:**" Cargo.toml README.md | sort | uniq -d

# Dependency versions in docs
grep -rh "sqlitegraph" *.md docs/*.md | grep -v "Binary file"

# Feature flag documentation
grep "^features = " Cargo.toml -A 20 | grep "^[" | sed 's/"//g' | sed 's/".*//' > /tmp/flags.txt
grep -rh "features\|--features" README.md MANUAL.md | grep -oE '(--features [a-z-]+|sqlite-backend|native-v3|geometric-backend|web-ui)' | sort -u
```

## Specific Checks for Common Issues

### Issue: Dependency Version Pin

When pinning a dependency (like `sqlitegraph = "=2.0.7"`):

**Required:**
1. ✅ CHANGELOG.md entry explaining why
2. ✅ Link to upstream bug report (if applicable)
3. ✅ Version specified in MANUAL.md dependencies section
4. ✅ Version specified in ARCHITECTURE.md components table

**Example:**
```markdown
### Fixed
- **Pinned sqlitegraph dependency to version 2.0.7**
  - sqlitegraph 2.1.2 introduced breaking change in SnapshotId::current()
  - See: /path/to/bug_report.md
  - Location: Cargo.toml
```

### Issue: Breaking API Changes

When changing public APIs:

**Required:**
1. ✅ CHANGELOG.md entry in `Changed` or `Deprecated` section
2. ✅ Migration guide in MANUAL.md or separate MIGRATION.md
3. ✅ Examples updated in README.md
4. ✅ OLD/NEW API comparison in documentation

### Issue: New Feature Flags

When adding feature flags:

**Required:**
1. ✅ Cargo.toml has feature definition
2. ✅ README.md or MANUAL.md documents what the flag does
3. ✅ Build instructions show how to enable
4. ✅ Default behavior documented

## Exit Criteria

Documentation is considered "in sync" when:

- ✅ All version numbers consistent across files
- ✅ All dependency versions specified in docs match `Cargo.lock`
- ✅ All recent changes have CHANGELOG entries
- ✅ All public APIs are documented
- ✅ All feature flags are documented
- ✅ All known bugs/limitations are noted
- ✅ All breaking changes have migration guides

## Reporting Format

End each sync run with a summary:

```markdown
## Sync Complete

**Status:** ✅ PASS / ⚠️ WARN / ❌ FAIL

**Files Checked:** N
**Issues Found:** N
**Files Updated:** N

**Next Review:** After next release / After feature X / After dependency Y update
```

## Automation Notes

This skill should be run:
- Before every release (required)
- After adding/changing dependencies (recommended)
- After API changes (recommended)
- As part of pre-commit checks for documentation changes (optional)

## Configuration

To customize which files are checked, edit this skill's prompt to add/remove paths in the "Documentation Files to Check" section.

Default files checked:
- CHANGELOG.md
- README.md
- MANUAL.md
- ARCHITECTURE.md
- CLAUDE.md
- docs/API_INTEGRATION.md
- docs/architecture/*.md
