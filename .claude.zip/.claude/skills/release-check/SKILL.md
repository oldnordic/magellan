---
name: release-check
description: Pre-release validation checklist for magellan crate releases
disable-model-invocation: true
---

# release-check

Run the complete pre-release validation checklist before publishing a new magellan version.

## Usage

```
/release-check [version]
```

## Checks Performed

1. **Version consistency**
   - `Cargo.toml` version matches intended release version
   - `MAGELLAN_SCHEMA_VERSION` in `src/migrate_cmd.rs` is correct

2. **Build verification**
   - `cargo check` passes
   - `cargo clippy --all-targets --all-features` passes
   - `cargo build --release` succeeds

3. **Test verification**
   - `cargo test` passes (lib tests)
   - `cargo test --features geometric-backend` passes if applicable

4. **Documentation**
   - `CLAUDE.md` version references are current
   - `MANUAL.md` exists and is up to date
   - CHANGELOG has entry for this version

5. **Feature flags**
   - All feature flags compile independently
   - Default features work out of the box

6. **CLI parity**
   - All library exports have CLI commands
   - Help text is current

## Example

```
/release-check 3.2.0
```

This runs the full checklist and reports any blockers before you publish.
