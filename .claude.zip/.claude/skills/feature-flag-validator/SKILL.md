---
name: feature-flag-validator
description: Validate that feature flag combinations are buildable and supported

Validates Rust feature flag combinations to ensure they're buildable and supported. Magellan has multiple feature flags (sqlite-backend, native-v3, geometric-backend, web-ui, external-tools-cfg, etc.) that need validation.

**What this skill does:**
- Tests feature flag combinations with `cargo check`
- Identifies conflicting or unsupported combinations
- Reports on which feature flags work together
- Validates feature flag dependencies

**When to invoke this skill:**
- Before adding new feature flags
- After modifying feature flag dependencies
- When troubleshooting build issues
- Validating release configurations

**Feature Flags in Magellan:**
- sqlite-backend (default)
- native-v3 (high-performance backend)
- geometric-backend (3D spatial indexing, requires ../geographdb-core)
- external-tools-cfg (C/C++/Java CFG extraction)
- web-ui (Axum web server)
- llvm-cfg (legacy LLVM CFG extraction)
- telemetry (race condition and loop detection)
- benchmarks (performance testing)
