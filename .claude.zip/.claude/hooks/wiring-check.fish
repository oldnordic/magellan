#!/usr/bin/env fish
# Wiring verification hook - runs after Rust file edits
# Checks for dead modules, parse-once consistency, debug prints

cd "$CLAUDE_PROJECT_DIR" 2>/dev/null || cd (pwd)

set -l issues 0

# 1. Dead module detection (only if src/graph/mod.rs exists)
if test -f src/graph/mod.rs
    echo "=== Dead Module Check ==="
    grep "pub mod" src/graph/mod.rs | while read -l line
        set -l mod (string match -rg '.*pub mod ([^;]*);.*' "$line")
        if test -n "$mod"
            set -l usages (grep -rn "$mod":: src/ --include="*.rs" | grep -v "$mod.rs:" | head -1)
            if test -z "$usages"
                echo "WARNING: Module '$mod' may be dead (declared but unused)"
                set issues (math $issues + 1)
            end
        end
    end
end

# 2. Indexing pipeline parse-once consistency (only if src/graph/ops.rs exists)
if test -f src/graph/ops.rs
    echo ""
    echo "=== Indexing Pipeline Parse-Once Check ==="
    set -l parse_count (grep -n "pool::with_parser" src/graph/ops.rs | grep '\.parse(' | wc -l)
    if test "$parse_count" -ne 2
        echo "WARNING: Found $parse_count pool::with_parser + .parse() calls (expected exactly 2: initial parsed_tree creation)"
        set issues (math $issues + 1)
    else
        echo "OK: Exactly 2 parse calls found (initial parsed_tree creation in both functions)"
    end
end

# 3. Debug message cleanup
echo ""
echo "=== Debug Message Cleanup ==="
if grep -rn "debug_print!" src/ 2>/dev/null
    echo "WARNING: Found debug_print! macros"
    set issues (math $issues + 1)
else
    echo "OK: No debug_print! macros found"
end

if grep -rn 'cfg(feature = "debug-prints")' src/ 2>/dev/null
    echo "WARNING: Found debug-prints feature references"
    set issues (math $issues + 1)
else
    echo "OK: No debug-prints feature references found"
end

# 4. cfg_hash column consistency (not function_hash)
echo ""
echo "=== cfg_hash Column Check ==="
set -l stale_refs (grep -rn "function_hash" src/ --include="*.rs" 2>/dev/null | grep -v "// .*function_hash")
if test -n "$stale_refs"
    echo "WARNING: Found function_hash references (should be cfg_hash)"
    set issues (math $issues + 1)
else
    echo "OK: No stale function_hash references found"
end

echo ""
if test $issues -gt 0
    echo "FAILED: $issues wiring issue(s) found"
    exit 1
else
    echo "PASSED: All wiring checks passed"
    exit 0
end
